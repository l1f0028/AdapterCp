package com.example.adpatercp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ArrayList<String[]> data = new ArrayList<>();
        data.add(new String[]{"Zafar Mushtaq Sam", "03024309493"});
        data.add(new String[]{"Sarfaraz Vopium", "03214407996"});
        data.add(new String[]{"Saad Salim Dar", "03214346444"});
        data.add(new String[]{"Abdul Basit Vopium", "03214164196"});
        data.add(new String[]{"Eagerness DB Lahore", "03224454898"});
        data.add(new String[]{"Shahid Shah PU", "03219424900"});
        data.add(new String[]{"Murtaza Help Desk PUCIT", "03214603506"});
        data.add(new String[]{"Zafar Mushtaq Sam", "03024309493"});
        data.add(new String[]{"Sarfaraz Vopium", "03214407996"});
        data.add(new String[]{"Saad Salim Dar", "03214346444"});
        data.add(new String[]{"Abdul Basit Vopium", "03214164196"});
        data.add(new String[]{"Eagerness DB Lahore", "03224454898"});
        data.add(new String[]{"Shahid Shah PU", "03219424900"});
        ListView listView = findViewById(R.id.listView);
        CustomAdapter adapter = new CustomAdapter(data);
        listView.setAdapter(adapter);
    }

    private class CustomAdapter extends BaseAdapter {

        private final ArrayList<String[]> data;

        public CustomAdapter(ArrayList<String[]> data) {
            this.data = data;
        }

        @Override
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
            }

            TextView nameTextView = convertView.findViewById(R.id.nameTextView);
            TextView phoneTextView = convertView.findViewById(R.id.phoneTextView);

            String[] currentItem = data.get(position);
            nameTextView.setText(currentItem[0]); // Name
            phoneTextView.setText(currentItem[1]); // Phone Number

            return convertView;
        }
    }
}
